#include"Cache.h"

using namespace minedreams;

namespace minedreams
{
	const std::istream& operator>>(
		std::istream & cin, Cache & cache)
	{
		std::string s;
		std::getline(cin, s);
		cache.add(s);
		return cin;
	}

	inline const std::ostream& operator<<(
		std::ostream & cout, Cache & cache)
	{
		cache.print(cout);
		return cout;
	}
}

//������Ĵ�ӡ����
void Cache::print(std::ostream & cout)
{
	std::string str2;
	for (const std::string & str : cache)
	{
		str2 += str;
	}
	cout.clear();
	cout << str2;
}

//����������Ӻ���
Cache& Cache::add(const std::string & str, const bool & is_visible)
{
	cache.insert(cache.end(), str);
	if (is_visible) std::cout << str;
	return *this;
}