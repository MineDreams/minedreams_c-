﻿#ifndef MAP_
#define MAP_

#include <iostream>
#include <stdexcept>
#include "Player.h"

inline static void check(const unsigned int x,
	const unsigned int y, const unsigned int size)
		throw(std::out_of_range)
{
	if (y >= size || x >= size)
		throw std::out_of_range("超过地图大小限制");
}

namespace minedreams
{
	class Player;
	//地图类
	class Map
	{
	private:
		//地图
		wchar_t** map;
		//初始化
		static wchar_t** init(unsigned int size);
		//地图大小
		const unsigned int size;
		//玩家
		Player* player;
		//苹果
		int apple_location[2] = { -1, -1 };
	public:
		//墙
		static const wchar_t BLOCK_WALL = '#';
		//苹果
		static const wchar_t BLOCK_APPLE = '⊕';

		Map(unsigned int size) :map(init(size)), size(size) {}

		//打印地图
		void print() { print(std::wcout); }

		void print(std::wostream & cout);

		friend std::wostream& operator<< (std::wostream & wcout, Map & map);

		//清空地图
		void clear();

		//设置地图
		//抛出：
		//	out_of_range - 当输入坐标大于边界时抛出
		void set(const unsigned int x, const unsigned int y, const wchar_t type)
			throw(std::out_of_range)
		{
			check(x, y, size);
			map[y + 1][x * 2 + 1] = map[y + 1][x * 2 + 2] = type;
		}

		//获取地图
		//抛出：
		//	out_of_range - 当输入坐标大于边界时抛出
		const wchar_t get(const unsigned int x, const unsigned int y)
			const throw(std::out_of_range)
		{
			return check(x, y, size), map[y + 1][x * 2 + 1];
		}

		//更新地图
		void update();

		//设置玩家
		void set_player(Player & player) { this->player = &player; }

		//添加一个苹果
		void creat_apple();

		const int* get_apple_location() const { return apple_location; }

		~Map();
	};

	inline std::wostream& operator<< (std::wostream & wcout, Map & map)
	{
		map.print(wcout);
	}

}

#endif
