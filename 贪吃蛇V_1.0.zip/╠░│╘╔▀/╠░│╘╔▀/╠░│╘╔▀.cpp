﻿#include <cstdlib>
#include <conio.h>
#include <thread>
#include <Windows.h>
#include <locale.h>
#include "Cache.h"
#include "Map.h"
#include "Player.h"
#include "pch.h"

using namespace minedreams;
using std::wcout;
using std::wcin;
using std::endl;
using std::cin;

DWORD WINAPI run_key(LPVOID);
static void run_move();

Player* player;
Map* map;
int size;

int main()
{
	system("title 贪吃蛇-c++");
	Cache cache;

	cache.add("欢迎游玩“贪吃蛇-c++”", true).enter(true)
		.add("下面开始设置游戏基本选项：", true).enter(true)
		.add("	请选择地图大小(10~50)：", true);

	//设置地图大小
	int size0;
	cinInt(wcin, size0, std::cerr, true,
		"		输入了错误的数据，请重新输入数字：");
	while (size0 < 10 || size0 > 50)
	{
		wcout << L"		数字范围在[10,50]：";
		cinInt(wcin, size0, std::cerr, true,
			"		输入了错误的数据，请重新输入数字：");
	}
	size = size0;
	cache.add(size0).enter();

	std::string name;
	cache.add("	请输入你的名称：", true);
	std::getline(cin, name);
	cache.add(name).enter();

	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cci;
	GetConsoleCursorInfo(hOut, &cci);
	cci.bVisible = FALSE;
	SetConsoleCursorInfo(hOut, &cci);
	wcout.imbue(std::locale("chs"));

	Map map0(size0);
	map = &map0;
	Player player0(L"src");
	player = &player0;
	player0.set_direction(Player::DIR_RIGHT);
	map0.set_player(player0);
	HANDLE thread_key = CreateThread(NULL, 0, run_key, NULL, 0, NULL);
	std::thread t(run_move);
	t.join();
	player0.print_die();
}

//移动
static void run_move()
{
	map->creat_apple();
	player->set_direction(Player::DIR_DOWN);
	for (;;)
	{
		player->set_player_location(size);
		if (!player->is_live())
			break;
		const int* xy = map->get_apple_location();
		if (player->getX() == xy[0] &&
			player->getY() == xy[1])
		{
			map->creat_apple();
			player->length_plus();
		}
		map->update();
		map->print();
		Sleep(300);
	}
	system("pause");
}

//键盘监视
DWORD WINAPI run_key(LPVOID)
{
	while (player->is_live())
	{
		if(::GetAsyncKeyState(VK_LEFT))
			player->set_direction(Player::DIR_LEFT);
		else if(::GetAsyncKeyState(VK_RIGHT))
			player->set_direction(Player::DIR_RIGHT);
		else if(::GetAsyncKeyState(VK_UP))
			player->set_direction(Player::DIR_UP);
		else if(::GetAsyncKeyState(VK_DOWN))
			player->set_direction(Player::DIR_DOWN);
	}
	return 0;
}