﻿#include "pch.h"
#include <sstream>

int minedreams::cinInt(std::wistream & cin, int & i,
	std::ostream & cout, const bool & is_loop,
	const std::string & text)
{
	int z = 0;
	bool b = minedreams::cinInt(cin, i);
	while (!b && is_loop)
	{
		++z;
		cout << text;
		b = minedreams::cinInt(cin, i);
	}
	return z;
}

bool minedreams::cinInt(std::wistream & cin, int & i)
{
	std::wstring c;
	std::getline(cin, c);
	std::wstringstream is;
	is << c;
	if (is >> i)
	{
		return true;
	}
	else
	{
		return false;
	}
}