#include "Map.h"
#include "pch.h"
#include <sstream>

using minedreams::Map;

static void delete_map(wchar_t** map, int size)
{
	for (int y = 0; y < size + 2; ++y)
	{
		delete[] map[y];
	}
	delete[] map;
}

wchar_t** Map::init(unsigned int size)
{
	wchar_t** c = new wchar_t*[size + 2];
	for (int i = 0; i < size + 2; ++i)
	{
		c[i] = new wchar_t[size * 2 + 2];
		for (int l = 0; l < size * 2 + 2; ++l)
		{
			c[i][l] = ' ';
		}
	}
	for (int i = 0; i < size * 2 + 2; ++i)
	{
		c[0][i] = BLOCK_WALL;
		c[size + 1][i] = BLOCK_WALL;
	}
	for (int i = 0; i < size + 2; ++i)
	{
		c[i][0] = BLOCK_WALL;
		c[i][size * 2 + 1] = BLOCK_WALL;
	}
	return c;
}

void Map::update()
{
	clear();
	set(player->head.x, player->head.y, Player::HEAD);
	for (const Player::player_location* pl : player->bodys)
	{
		set(pl->x, pl->y, Player::BODY);
	}
	if (apple_location[0] != -1)
	{
		set(apple_location[0], apple_location[1], BLOCK_APPLE);
	}
	if (bad_apple_location[0] != -1)
	{
		set(bad_apple_location[0], bad_apple_location[1], BLOCK_BAD_APPLE);
	}
}

void Map::print(std::wostream & wcout)
{
	using std::cout;
	system("cls");
	bool b = true;
	for (int y = 0; y < size + 2; ++y)
	{
		for (int x = 0; x < size * 2 + 2; ++x)
		{
			if (map[y][x] == BLOCK_APPLE)
			{
				if(b) cout << "��";
				b = !b;
			}
			else if (map[y][x] == Player::BODY)
			{
				if(b) cout << "��";
				b = !b;
			}
			else if (map[y][x] == BLOCK_BAD_APPLE)
			{
				if (b) cout << "��";
				b = !b;
			}
			else
				std::wcout << map[y][x];
		}
		if (y == 5)
		{
			wcout << L"\t\t���ƣ�" << player->player_name;
		}
		else if (y == 6)
		{
			cout << "\t\t���ȣ�" << player->length;
		}
		else if (y == 7)
		{
			cout << "\t\t���֣�" << player->score;
		}
		wcout << std::endl;
	}
}

void Map::creat_bad_apple()
{
	int x, y;
	do {
		x = random(size);
		y = random(size);
	} while (get(x, y) != ' ');
	bad_apple_location[0] = x;
	bad_apple_location[1] = y;
}

void Map::creat_apple()
{
	int x, y;
	do {
		x = random(size);
		y = random(size);
	} while (get(x, y) != ' ');
	apple_location[0] = x;
	apple_location[1] = y;
}

void Map::clear()
{
	for (int y = 0; y < size; ++y)
	{
		for (int x = 0; x < size; ++x)
		{
			set(x, y, ' ');
		}
	}
}

Map::~Map()
{
	delete_map(map, size);
}