﻿#include <cstdlib>
#include <conio.h>
#include <thread>
#include <Windows.h>
#include <locale.h>
#include "Cache.h"
#include "Map.h"
#include "Player.h"
#include "pch.h"

#pragma comment(lib, "winmm.lib")

using namespace minedreams;
using std::wcout;
using std::wcin;
using std::endl;
using std::cin;

DWORD WINAPI run_key(LPVOID);
static bool run_move();

static Player* player;
static Map* map;
static int size;
static bool stop = false;

static int next()
{
	while (true)
	{
		if (_kbhit())
		{
			switch (_getch())
			{
			case 27:
				return 0;
			case 114:
				TCHAR exeFullPath[MAX_PATH];
				memset(exeFullPath, 0, MAX_PATH);
				GetModuleFileName(NULL, exeFullPath, MAX_PATH);
				char c[MAX_PATH];
				WideCharToMultiByte(CP_ACP, 0, exeFullPath, -1, c, MAX_PATH, NULL, NULL);
				system("cls");
				system(c);
				return 1;
			}
		}
	}
}

int main()
{
	wcout.imbue(std::locale("chs"));
	system("title 贪吃蛇-c++");
	Cache cache;

	cache.add(L"欢迎游玩“贪吃蛇-c++”", true).enter(true)
		.add(L"下面开始设置游戏基本选项：", true).enter(true)
		.add(L"	请选择地图大小(10~50)：", true);

	//设置地图大小
	cinInt(wcin, size, std::cerr, true,
		"		输入了错误的数据，请重新输入数字：");
	while (size < 10 || size > 50)
	{
		std::cout << "		数字范围在[10,50]：";
		cinInt(wcin, size, std::cerr, true,
			"		输入了错误的数据，请重新输入数字：");
	}
	cache.add(size).enter();
	system("cls");
	cache.print();

	std::wstring name;
	cache.add("	请输入你的名称：", true);
	std::getline(wcin, name);
	cache.add(name).enter();

	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cci;
	GetConsoleCursorInfo(hOut, &cci);
	cci.bVisible = FALSE;
	SetConsoleCursorInfo(hOut, &cci);
	wcout.imbue(std::locale("chs"));

	Map map0(size);
	map = &map0;
	Player player0(name);
	player = &player0;
	player0.set_direction(Player::DIR_RIGHT);
	map0.set_player(player0);
	HANDLE thread_key = CreateThread(NULL, 0, run_key, NULL, 0, NULL);
	map->creat_apple();
	map->creat_bad_apple();
	player->set_direction(Player::DIR_DOWN);
	std::thread t(
		[](){
			while (run_move() && !stop)
			{
				Sleep(280);
			}
			std::cout << "“R”-重新开始，“ESC”-继续";
			if(next() == 1) return 0;
		});
	t.join();
	player0.print_die();
	std::cout << "“R”-重新开始，“ESC”-退出";
	return next();
}

//移动
static bool run_move()
{
	while (stop);
	player->set_player_location(size);
	if (!player->is_live())
		return false;
	const int* xy = map->get_apple_location();
	if (player->getX() == xy[0] &&
		player->getY() == xy[1])
	{
		map->creat_apple();
		player->length_plus();
		player->score_plus(2);
		PlaySound(L"apple.wav", NULL, SND_FILENAME | SND_ASYNC);
	}
	else if (player->getX() == (xy = map->get_bad_apple_location())[0] &&
		player->getY() == xy[1])
	{
		map->creat_bad_apple();
		player->length_minus();
		player->score_plus(-1);
		PlaySound(L"apple.wav", NULL, SND_FILENAME | SND_ASYNC);
	}
	map->update();
	map->print();
	while (stop);
	return player->is_live();
}

//键盘监视
DWORD WINAPI run_key(LPVOID)
{
	while (player->is_live())
	{
		if (_kbhit())
		{
			switch (_getch())
			{
			case 77 :
				player->set_direction(Player::DIR_RIGHT);
				break;
			case 72 :
				player->set_direction(Player::DIR_UP);
				break;
			case 80 :
				player->set_direction(Player::DIR_DOWN);
				break;
			case 75 :
				player->set_direction(Player::DIR_LEFT);
				break;
			case 32 :
				stop = !stop;
				break;
			}
		}
	}
	return 0;
}