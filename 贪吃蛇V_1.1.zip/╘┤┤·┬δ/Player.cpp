#include "Player.h"
#include <iostream>
#include <string>
#include "pch.h"

using minedreams::Player;

void Player::set_last_location()
{
	if (bodys.size() == 0)
	{
		last_location[0] = head.x;
		last_location[1] = head.y;
	}
	else
	{
		player_location* p = bodys.at(bodys.size() - 1);
		last_location[0] = p->x;
		last_location[1] = p->y;
	}
}

void Player::length_minus()
{
	if (--length == 0)
	{
		die();
		return;
	}
	bodys.erase(--bodys.end());
}

void Player::length_plus()
{
	++length;
	player_location* pl = new player_location{
		last_location[0], last_location[1], BODY
	};
	bodys.insert(bodys.end(), pl);
}

void Player::set_player_location(const int & direction, int size)
{
	dir = dirc;
	switch (direction)
	{
	case DIR_DOWN :
		if (head.y + 1 >= size)
		{
			die();
			return;
		}
		move(0, 1);
		break;
	case DIR_UP :
		if (head.y - 1 < 0)
		{
			die();
			return;
		}
		move(0, -1);
		break;
	case DIR_LEFT :
		if (head.x - 1 < 0)
		{
			die();
			return;
		}
		move(-1, 0);
		break;
	case DIR_RIGHT :
		if (head.x + 1 >= size)
		{
			die();
			return;
		}
		move(1, 0);
		break;
	}
	dir = dirc;
}

void Player::move(int x, int y)
{
	set_last_location();
	int xy[2] = { head.x, head.y };
	setY(getY() + y);
	setX(getX() + x);
	int xyc[2] = { -1, -1 };
	for (player_location* pl : bodys)
	{
		if (xy[0] == getX() && xy[1] == getY())
		{
			die();
			return;
		}
		xyc[0] = pl->x;
		xyc[1] = pl->y;
		pl->x = xy[0];
		pl->y = xy[1];
		xy[0] = xyc[0];
		xy[1] = xyc[1];
	}
}

void Player::die()
{
	is_lives = false;
}

void Player::print_die()
{
	using std::wcout;
	using std::endl;

	system("cls");
	wcout.width(10);
	wcout << L"������ƣ�" << player_name << endl;
	wcout.width(10);
	wcout << L"��ҷ�����" << score << endl;
	wcout.width(10);
	wcout << L"��ҳ��ȣ�" << length << endl;
}

void Player::for_each(const bool & is_head,
	bool(*pf)(player_location*))
{
	bool b = is_head ? pf(&head) : true;
	for (player_location* var : bodys)
	{
		if (!pf(var)) break;
	}
}

Player::~Player()
{
	for_each(false, [](player_location* pl) -> bool {
		delete pl;
		return true;
	});
}