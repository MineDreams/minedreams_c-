﻿#include "pch.h"
#include "Options.h"

using namespace minedreams;

int main()
{
	Options o = Options();
	o.start();
}